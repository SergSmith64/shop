<?php
/**
 * Booster for WooCommerce - Mini plugin customizations
 *
 * @author  Pluggabl LLC. 
 */