(function ($) {

    /* DOM elements */
    var $filter = $('[data-premmerce-filter]');
    var $control = $filter.find('[data-premmerce-filter-link]');

    /* Event handlers */
    $control.on('change', followLink);

    /**
     * Launch filter after clicking on radio or checkbox control
     */
    function followLink(event) {
        event.preventDefault();
        location.href = $(this).attr('data-premmerce-filter-link');
    }


    /**
     * Price slider
     */
    //Selectors init
    var fieldScope = $('[data-premmerce-filter]');
    var form = $('[data-premmerce-filter-price-form]');
    var fieldMin = 'data-premmerce-filter-min';
    var fieldMax = 'data-premmerce-filter-max';
    var slider = 'data-premmerce-filter-range-slider';

    //Default valued at start
    var initialMinVal = parseFloat(fieldScope.find('[' + fieldMin + ']').attr(fieldMin));
    var initialMaxVal = parseFloat(fieldScope.find('[' + fieldMax + ']').attr(fieldMax));

    //Values after applying filter
    var curMinVal = parseFloat(fieldScope.find('[' + fieldMin + ']').attr('value'));
    var curMaxVal = parseFloat(fieldScope.find('[' + fieldMax + ']').attr('value'));

    //Setting value into form inputs when slider is moving
    fieldScope.find('[' + slider + ']').slider({
        min: initialMinVal,
        max: initialMaxVal,
        values: [curMinVal, curMaxVal],
        range: true,
        slide: function (event, elem) {
            var instantMinVal = elem.values[0];
            var instantMaxVal = elem.values[1];

            fieldScope.find('[' + fieldMin + ']').val(instantMinVal);
            fieldScope.find('[' + fieldMax + ']').val(instantMaxVal);

        },
        change: function () {
            form.trigger('submit');
            fieldScope.find('[' + fieldMin + '], [' + fieldMax + ']').attr('readOnly', true);
        }
    });


    //Setting value slider ranges when form inputs are changing
    fieldScope.find('[' + fieldMin + '], [' + fieldMax + ']').on('change', function () {
        $('[' + slider + ']').slider('values', [
            fieldScope.find('[' + fieldMin + ']').val(),
            fieldScope.find('[' + fieldMax + ']').val()
        ]);
    });


    /**
     * Toogle filter block visibility
     */
    $(document).on('click', '[data-premerce-filter-drop-handle]', function (e) {
        e.preventDefault();

        $(this).closest('[data-premmerce-filter-drop-scope]').find('[data-premmerce-filter-inner]').slideToggle(300);
        $(this).closest('[data-premmerce-filter-drop-scope]').find('[data-premmerce-filter-drop-ico]').toggleClass('hidden', 300);
    });


    /**
     * Positioning scroll into the middle of checked value
     * Working only if scroll option in filter setting is true
     */
    $('[data-filter-scroll]').each(function () {
        var frame = $(this);
        var fieldActive = frame.find('[data-filter-control]:checked').first().closest('[data-filter-control-checkgroup]').find('[data-filter-control-label]');

        if (fieldActive.size() > 0) {
            var fieldActivePos = fieldActive.offset().top - frame.offset().top;
            frame.scrollTop(fieldActivePos - (frame.height() / 2 - fieldActive.height()));
        }
    });
})(jQuery);