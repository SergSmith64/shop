<?php

if(!defined('ABSPATH')){
	exit; // Exit if accessed directly
}

/**
 * @var array $attributes
 * @var array $args
 * @var array $prices
 * @var array $includeFields
 * @var string $title
 * @var string $formAction
 *
 * use instance['title'] to show widget title
 *
 * $attribute->display_type = '' - Default , 'scroll' - Scroll ,'dropdown' - Dropdown ,'scroll_dropdown' - Scroll + Dropdown
 * $attribute->has_checked = true, false
 */

use Premmerce\Filter\FilterPlugin;

?>

<?php echo $args['before_widget']; ?>

<?php if(!empty($instance['title'])): ?>
	<?php echo $args['before_title'] . $instance['title'] . $args['after_title'] ?>
<?php endif; ?>

    <div class="filter" data-premmerce-filter>
		<?php if(!empty($prices['min_price']) && !empty($prices['max_price'])): ?>
            <div class="filter__item">

                <div class="filter__header">
                    <div class="filter__title">
						<?php _e('Filter by price', FilterPlugin::DOMAIN); ?>
                    </div>
                </div>
                <div class="filter__inner">
                    <form action="<?=$formAction?>" method="get" class="filter__price-form"
                          data-premmerce-filter-price-form>
                        <div class="filter__price-control-group">
                            <div class="filter__price-control-column">
                                <input class="filter__price-control" type="number"
                                       data-premmerce-filter-min="<?=$prices['min_price']?>" name="min_price"
                                       value="<?=$prices['min_selected']?>">
                            </div>
                            <div class="filter__price-control-column">
                                <input class="filter__price-control" type="number"
                                       data-premmerce-filter-max="<?=$prices['max_price']?>" name="max_price"
                                       value="<?=$prices['max_selected']?>">
                            </div>
                        </div>
                        <div class="filter__range-slider">
                            <div class="pc-range-slider">
                                <div class="pc-range-slider__wrapper">
                                    <div class="pc-range-slider__control" data-premmerce-filter-range-slider></div>
                                </div>
                            </div>
                        </div>
						<?php wc_query_string_form_fields(apply_filters('premmerce_product_filter_price_include_fields', $_GET)) ?>
                    </form>
                </div>
            </div>
		<?php endif; ?>

		<?php foreach($attributes as $attribute): ?>

            <div class="filter__item" data-premmerce-filter-drop-scope>

				<?php

				$has_checked = $attribute->has_checked;
				$dropdown    = $attribute->display_type == 'dropdown' && !$has_checked || $attribute->display_type == 'scroll_dropdown' && !$has_checked;
				$scroll      = $attribute->display_type == 'scroll' || $attribute->display_type == 'scroll_dropdown';

				?>

                <div class="filter__header" <?=$dropdown? 'data-premerce-filter-drop-handle' : '';?>>
                    <div class="filter__title">
						<?=$attribute->attribute_label?>
                    </div>

					<?php if($dropdown) : ?>
                        <div class="filter__handle">
                            <div class="filter__handle-ico filter__handle-ico--plus"
                                 data-premmerce-filter-drop-ico>
                                <div class="filter__icon-plus"></div>
                            </div>
                            <div class="filter__handle-ico filter__handle-ico--minus hidden"
                                 data-premmerce-filter-drop-ico>
                                <div class="filter__icon-minus"></div>
                            </div>
                        </div>
					<?php endif; ?>
                </div>

				<?php if(isset($attribute->terms)) : ?>
                    <div class="filter__inner <?=$dropdown? 'filter__inner--js-hidden' : '';?> <?=$scroll? 'filter__inner--scroll' : '';?>"
                         data-premmerce-filter-inner <?=$scroll? 'data-filter-scroll' : '';?>>
						<?php if($attribute->html_type == 'select') : ?>
                            <select onchange="window.location.assign(this.value);"
                                    class="filter__scroll form-control input-sm">
                                <option value="<?=$attribute->reset_url?>"><?php printf(__('Any %s', 'woocommerce'), $attribute->attribute_label) ?></option>
								<?php foreach($attribute->terms as $term): ?>
									<?php $selected = $term->checked? 'selected' : ''; ?>
                                    <option <?=$selected?>
                                            value="<?=$term->link?>"><?=$term->name . ' (' . ($term->count) . ')'?></option>
								<?php endforeach ?>
                            </select>
						<?php else: ?>
                            <div class="filter__properties-list">
								<?php foreach($attribute->terms as $term): ?>
                                    <div class="filter__properties-item">
                                        <div class="filter__checkgroup" data-filter-control-checkgroup>
                                            <div class="filter__checkgroup-body">
                                                <div class="filter__checkgroup-link">
													<?php if($attribute->html_type == 'checkbox') : ?>
                                                        <input class="filter__checkgroup-control"
														       <?php if($term->checked): ?>checked<?php endif ?>
                                                               type="checkbox"
                                                               data-filter-control
                                                               id="filter-checkgroup-id-<?=$term->term_id?>"
															<?=$term->count == 0? 'disabled' : ''?>
                                                               data-premmerce-filter-link="<?=$term->link?>">
													<?php elseif($attribute->html_type == 'radio') : ?>
                                                        <input class="filter__checkgroup-control"
														       <?php if($term->checked): ?>checked<?php endif ?>
                                                               type="radio"
                                                               data-filter-control
                                                               id="filter-checkgroup-id-<?=$term->term_id?>"
															<?=$term->count == 0? 'disabled' : ''?>
                                                               data-premmerce-filter-link="<?=$term->link?>">
													<?php endif; ?>
                                                    <label class="filter__checkgroup-check"
                                                           data-filter-control-label
                                                           for="filter-checkgroup-id-<?=$term->term_id?>"></label>
                                                    <label class="filter__checkgroup-title <?=$term->count == 0? 'disabled' : ''?>"
                                                           for="filter-checkgroup-id-<?=$term->term_id?>">
														<?=$term->name?>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="filter__checkgroup-aside">
                                    <span class="filter__checkgroup-count">
                                        <?='(' . ($term->count) . ')'?>
                                    </span>
                                            </div>
                                        </div>
                                    </div>
								<?php endforeach ?>
                            </div>
						<?php endif; ?>
                    </div>
				<?php endif ?>
            </div>
		<?php endforeach ?>
    </div>
<?php echo $args['after_widget']; ?>