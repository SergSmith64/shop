<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * @var array $activeFilters
 * @var array $args
 * @var array $instance
 */

?>

<?php echo $args['before_widget']; ?>

<?php if(!empty($instance['title'])): ?>
	<?php echo $args['before_title'] . $instance['title'] . $args['after_title'] ?>
<?php endif; ?>

<div class="pc-active-filter">
    <div class="pc-active-filter__list">
        <?php foreach($activeFilters as $item): ?>
            <div class="pc-active-filter__list-item">
                <a class="pc-active-filter__item-link" rel="nofollow" aria-label="<?=esc_attr__('Remove filter', 'woocommerce')?>" href="<?=$item['link']?>">
                    <span class="pc-active-filter__item-text-el">
                        <?=$item['title']?>
                    </span>
                    <span class="pc-active-filter__item-delete">
                        x
                    </span>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php echo $args['after_widget']; ?>
