<?php defined('WPINC') || die;

\Premmerce\Filter\Admin\Settings\PermalinkSettings::getInstance()->show();