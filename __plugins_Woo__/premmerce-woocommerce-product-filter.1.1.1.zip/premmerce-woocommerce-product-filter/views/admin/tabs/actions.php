<?php defined('WPINC') || die;

use Premmerce\Filter\FilterPlugin;

?>
<div class="alignleft actions bulkactions">
    <label for="bulk-action-selector-top"
           class="screen-reader-text"><?php _e('Select bulk action', FilterPlugin::DOMAIN) ?></label>
    <select data-bulk-action-select>
		<?php foreach($actions as $key => $title): ?>
			<?php if(is_array($title)): ?>
                <optgroup label="<?=$key?>">
					<?php foreach($title as $itemKey => $itemTitle): ?>
                        <option value="<?php echo $itemKey ?>"><?php echo $itemTitle ?></option>
					<?php endforeach; ?>
                </optgroup>
			<?php else: ?>
                <option value="<?php echo $key ?>"><?php echo $title ?></option>
			<?php endif; ?>
		<?php endforeach; ?>
    </select>
    <button type="button" data-action="<?php echo $dataAction ?>"
            class="button"><?php _e('Apply', FilterPlugin::DOMAIN) ?></button>
</div>