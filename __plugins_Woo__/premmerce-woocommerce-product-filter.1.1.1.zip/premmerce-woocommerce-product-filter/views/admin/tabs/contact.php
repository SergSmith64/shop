<?php defined('WPINC') || die;

if(function_exists('premmerce_pwpf_fs')){
	premmerce_pwpf_fs()->_contact_page_render();
}
