<?php defined('WPINC') || die;

\Premmerce\Filter\Admin\Settings\Settings::getInstance()->show();