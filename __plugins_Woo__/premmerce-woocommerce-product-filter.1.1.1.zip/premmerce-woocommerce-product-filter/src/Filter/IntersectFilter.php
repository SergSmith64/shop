<?php namespace Premmerce\Filter\Filter;

use WC_Query;

class IntersectFilter{

	/**
	 * @var FilterModel
	 */
	private $model;

	/**
	 * @var array
	 */
	private $items = null;

	/**
	 * @var bool
	 */
	private $hideEmpty = false;

	/**
	 * IntersectFilter constructor.
	 */
	public function __construct(){
		$this->model = new FilterModel(new FilterCache());
	}

	/**
	 * @param bool $hideEmpty
	 */
	public function setHideEmpty($hideEmpty){
		$this->hideEmpty = $hideEmpty;
	}


	/**
	 * Clear filter cache
	 */
	public function clearCache(){
		$this->model->clearCache();
	}

	/**
	 * Warm up cache files
	 *
	 */
	public function warmUpCache(){
		$this->model->warmUpCache();
	}

	/**
	 * Store search query
	 *
	 * @param $searchQuery
	 *
	 * @return void
	 */
	public function setSearchQuery($searchQuery){
		$this->model->setSearchQuery($searchQuery);
	}

	/**
	 * Returns filter items
	 *
	 * @return array
	 */
	public function getItems(){

		if(!is_null($this->items)){
			return $this->items;
		}

		$items = $this->model->getAttributes();

		$items = $this->model->getTerms($items);

		$items = $this->model->addTermProducts($items);

		$items = $this->countProductsForAttributes($items);

		$this->items = $items;

		return $items;
	}

	public function getPrices(){
		return $this->model->getPrices();
	}

	/**
	 * Count product for each attribute terms for current query
	 *
	 * @param array $attributes
	 *
	 * @return array
	 */
	private function countProductsForAttributes(array $attributes){
		$queriedTaxonomyProducts = $this->getQueriedTaxonomyProducts($attributes);

		$queriedProducts = $this->model->getProductIdsByMainQuery(array_keys($attributes));

		foreach($attributes as $key => $attribute){
			foreach($attribute->terms as $slug => $term){
				$term->count = $this->getTermCount($term, $queriedProducts, $queriedTaxonomyProducts, $attribute);
			}
		}

		return $attributes;
	}

	/**
	 * Get product ids for selected taxonomy terms
	 *
	 * @param $taxonomies
	 *
	 * @return array
	 */
	private function getQueriedTaxonomyProducts($taxonomies){
		$taxQuery = WC_Query::get_main_tax_query();

		$taxonomyProducts = [];
		foreach($taxQuery as $key => $item){
			if(is_array($item) && array_key_exists($item['taxonomy'], $taxonomies)){
				$taxonomyName = $item['taxonomy'];

				$taxonomy = $taxonomies[ $taxonomyName ];

				$taxonomyTerms = $taxonomies[ $taxonomyName ]->terms;

				$products = null;

				foreach($item['terms'] as $term){
					$termProducts = !empty($taxonomyTerms[ $term ]->products)? $taxonomyTerms[ $term ]->products : [];

					if($term && is_array($termProducts)){
						if(is_null($products)){
							$products = $termProducts;
						}elseif($taxonomy->filter_query_type == 'or'){
							$products = $products + $termProducts;
						}else{
							$products = array_intersect_key($products, $termProducts);
						}
					}
				}

				$taxonomyProducts[ $taxonomyName ] = $products;
			}
		}

		return $taxonomyProducts;
	}

	/**
	 * @param object $term
	 * @param array $queriedProducts - products by main query
	 *
	 * @param array $queriedTaxonomyProducts - products by selected taxonomy terms
	 *
	 * @return int
	 *
	 */
	private function getTermCount($term, $queriedProducts, $queriedTaxonomyProducts){
		if(empty($term->products) || empty($queriedProducts)){
			return 0;
		}

		$products = array_intersect_key($term->products, $queriedProducts);


		if(empty($products)){
			return 0;
		}

		if(empty($queriedTaxonomyProducts)){
			return count($products);
		}

		foreach($queriedTaxonomyProducts as $taxonomy => $taxonomyProducts){
			if($taxonomy !== $term->taxonomy){
				$products = array_intersect_key($products, $taxonomyProducts);
			}
		}

		return count($products);
	}
}
