<?php namespace Premmerce\Filter\Admin\Settings;


abstract class BaseSettings{


	/**
	 * @var string
	 */
	protected $page;

	/**
	 * @var string
	 */
	protected $group;

	/**
	 * @var string
	 */
	protected $optionName;

	/**
	 * @var array
	 */
	protected $options;

	/**
	 * @var static
	 */
	protected static $instance;

	public static function getInstance(){

		if(!isset(static::$instance[ static::class ])){
			static::$instance[ static::class ] = new static();
		}

		return static::$instance[ static::class ];
	}

	private function __construct(){
	}

	abstract public function init();

	protected function registerSettings($settings, $page, $optionName){
		$callbacks = [
			'checkbox' => [$this, 'checkboxCallback'],
			'text'     => [$this, 'inputCallback'],
		];

		foreach($settings as $sectionId => $section){
			add_settings_section($sectionId, $section['label'], null, $page);

			foreach($section['fields'] as $fieldId => $field){
				$title                = isset($field['title'])? $field['title'] : '';
				$field['label_for']   = $fieldId;
				$field['option_name'] = $optionName;
				add_settings_field($fieldId, $title, $callbacks[ $field['type'] ], $page, $sectionId, $field);
			}
		}
	}


	/**
	 * @param array $args
	 */
	public function checkBoxCallback($args){
		$checkbox = '<label><input type="checkbox" name="%s[%s]" %s >%s</label>';
		$checked  = $this->getOption($args['label_for']);

		if($checked == '1'){
			$checked = 'on';
		}

		printf($checkbox, $args['option_name'], esc_attr($args['label_for']), checked('on', $checked, false), $args['label']);
	}

	/**
	 * @param array $args
	 */
	public function inputCallback($args){
		$checkbox = '<input type="text" name="%s[%s]" value="%s" placeholder="%s">';

		printf($checkbox, $this->optionName, esc_attr($args['label_for']), $this->getOption($args['label_for']), $args['placeholder']);
	}

	public function show(){
		print('<form action="' . admin_url('options.php') . '" method="post">');

		settings_errors();

		settings_fields($this->group);

		do_settings_sections($this->page);

		submit_button();
		print('</form>');
	}

	/**
	 * @param $name
	 * @param string $key
	 * @param mixed|null $default
	 *
	 * @return mixed|null
	 */
	public function getOption($key, $default = null){

		if(is_null($this->options)){
			$this->options = get_option($this->optionName);
		}

		return isset($this->options[ $key ])? $this->options[ $key ] : $default;
	}

}