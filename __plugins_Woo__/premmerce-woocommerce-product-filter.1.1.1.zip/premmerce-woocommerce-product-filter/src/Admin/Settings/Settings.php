<?php namespace Premmerce\Filter\Admin\Settings;

class Settings extends BaseSettings{


	protected $page = 'premmerce-filter-admin-settings';
	protected $group = 'premmerce_filter';
	protected $optionName = 'premmerce_filter_settings';


	public function init(){

		register_setting($this->group, $this->optionName);

		$settings = [
			'behavior'      => [
				'label'  => __('Behavior', 'premmerce-filter'),
				'fields' => [
					'hide_empty'        => [
						'type'  => 'checkbox',
						'label' => __('Hide empty terms', 'premmerce-filter'),
					],
					'show_price_filter' => [
						'type'  => 'checkbox',
						'label' => __('Show price filter', 'premmerce-filter'),
					],
				],
			],
			'show_on_pages' => [
				'label'  => __('Show filter on pages', 'premmerce-filter'),
				'fields' => [
					'product_cat'   => [
						'type'  => 'checkbox',
						'label' => __('Product category', 'premmerce-filter'),
					],
					'tag'           => [
						'type'  => 'checkbox',
						'label' => __('Tag', 'premmerce-filter'),
					],
					'product_brand' => [
						'type'  => 'checkbox',
						'label' => __('Brand', 'premmerce-filter'),
					],
					'search'        => [
						'type'  => 'checkbox',
						'label' => __('Search', 'premmerce-filter'),
					],
					'shop'          => [
						'type'  => 'checkbox',
						'label' => __('Store', 'premmerce-filter'),
					],
				],
			],

		];

		$this->registerSettings($settings, $this->page, $this->optionName);

	}

}