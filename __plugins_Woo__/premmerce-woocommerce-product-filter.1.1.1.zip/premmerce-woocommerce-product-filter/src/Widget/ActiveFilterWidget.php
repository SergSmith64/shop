<?php namespace Premmerce\Filter\Widget;


class ActiveFilterWidget extends \WP_Widget{
	/**
	 * FilterWidget constructor.
	 */
	public function __construct(){
		parent::__construct(
			'premmerce_filter_active_filters_widget',
			__('Premmerce active filters', 'premmerce-filter'),
			[
				'description' => __('Product attributes active filters', 'premmerce-filter'),
			]
		);
	}


	/**
	 * @param array $args
	 * @param array $instance
	 */
	public function widget($args, $instance){

		if(apply_filters('premmerce_product_filter_active', false)){


			$url = $_SERVER['REQUEST_URI'];

			$items = apply_filters('premmerce_product_filter_items', []);

			$prices = [
				'min_price' => isset($_GET['min_price'])? sanitize_text_field($_GET['min_price']) : 0,
				'max_price' => isset($_GET['max_price'])? sanitize_text_field($_GET['max_price']) : 0,
			];

			$ratings = isset($_GET['rating_filter'])? array_filter(array_map('absint', explode(',', $_GET['rating_filter']))) : [];

			$prices = array_filter($prices);

			$activeFilters = [];

			if(count($items) || count($prices) || count($ratings)){
				foreach($items as $taxonomy){
					foreach($taxonomy->terms as $term){
						if($term->checked){

							if($taxonomy->html_type == 'checkbox'){
								$link = $term->link;
							}else{
								$link = $taxonomy->reset_url;
							}


							$activeFilters[ $term->term_id ] = [
								'title' => esc_html($term->name),
								'link'  => esc_url($link),
							];
						}
					}
				}

				$titles = apply_filters('premmerce_filter_active_filters_price_titles', [
					'min_price' => __('Min %s', 'woocommerce'),
					'max_price' => __('Max %s', 'woocommerce'),
				]);


				foreach($prices as $key => $price){
					$link                  = remove_query_arg($key, $url);
					$title                 = sprintf($titles[ $key ], wc_price($price));
					$activeFilters[ $key ] = ['title' => $title, 'link' => esc_url($link),];
				}

				$ratingTitle = __('Rated %s out of 5', 'woocommerce');
				foreach($ratings as $rating){
					$link_ratings = implode(',', array_diff($ratings, [$rating]));
					$link         = $link_ratings? add_query_arg('rating_filter', $link_ratings) : remove_query_arg('rating_filter', $url);

					$activeFilters[ 'rating_filter_' . $rating ] = [
						'title' => sprintf($ratingTitle, $rating),
						'link'  => $link,
					];
				}

				if(count($activeFilters) > 0){
					do_action('premmerce_product_active_filters_render', compact('activeFilters', 'args', 'instance'));
				}

			}
		}

	}

	/**
	 * @param array $new_instance
	 * @param array $old_instance
	 *
	 * @return array
	 */
	public function update(
		$new_instance, $old_instance
	){
		$instance          = [];
		$instance['title'] = strip_tags($new_instance['title']);

		return $instance;
	}

	/**
	 * @param array $instance
	 *
	 * @return string|void
	 */
	public function form(
		$instance
	){
		do_action('premmerce_product_filter_widget_form_render', [
			'title'  => isset($instance['title'])? $instance['title'] : '',
			'widget' => $this,
		]);
	}

}