<?php namespace Premmerce\Filter\Widget;

class FilterWidget extends \WP_Widget{


	/**
	 * FilterWidget constructor.
	 */
	public function __construct(){
		parent::__construct(
			'premmerce_filter_filter_widget',
			__('Premmerce filter', 'premmerce-filter'),
			[
				'description' => __('Product attributes filter', 'premmerce-filter'),
			]
		);
	}

	/**
	 * @param array $args
	 * @param array $instance
	 */
	public function widget($args, $instance){
		if(apply_filters('premmerce_product_filter_active', false)){

			$path  = $_SERVER['REQUEST_URI'];
			$parts = explode('?', $path);
			$path  = $parts[0];

			$formAction = preg_replace('%\/page/[0-9]+%', '', home_url($path));

			$items = apply_filters('premmerce_product_filter_items', []);

			if(apply_filters('premmerce_product_filter_hide_empty', false)){
				foreach($items as $attribute => $item){
					foreach($item->terms as $slug => $term){
						if($term->count < 1){
							unset($item->terms[ $slug ]);
						}
					}

					if(empty($item->terms)){
						unset($items[ $attribute ]);
					}
				}
			}

			do_action('premmerce_product_filter_render', [
				'args'       => $args,
				'attributes' => $items,
				'prices'     => apply_filters('premmerce_product_filter_prices', []),
				'formAction' => $formAction,
				'instance'   => $instance,
			]);

		}
	}

	/**
	 * @param array $new_instance
	 * @param array $old_instance
	 *
	 * @return array
	 */
	public function update($new_instance, $old_instance){
		$instance          = [];
		$instance['title'] = strip_tags($new_instance['title']);

		return $instance;
	}

	/**
	 * @param array $instance
	 *
	 * @return string|void
	 */
	public function form($instance){
		do_action('premmerce_product_filter_widget_form_render', [
			'title'  => isset($instance['title'])? $instance['title'] : '',
			'widget' => $this,
		]);
	}
}
