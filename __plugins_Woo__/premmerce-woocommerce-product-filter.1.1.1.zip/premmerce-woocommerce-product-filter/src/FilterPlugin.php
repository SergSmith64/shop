<?php namespace Premmerce\Filter;

use Premmerce\Filter\Admin\Admin;
use Premmerce\Filter\Admin\Settings;
use Premmerce\Filter\Filter\FilterCache;
use Premmerce\SDK\V1\FileManager\FileManager;
use Premmerce\SDK\V1\Notifications\AdminNotifier;
use Premmerce\SDK\V1\Plugin\PluginInterface;

/**
 * Class FilterPlugin
 *
 * @package Premmerce\Filter
 */
class FilterPlugin implements PluginInterface{

	const DOMAIN = 'premmerce-filter';

	const OPTION_ATTRIBUTES = 'premmerce_filter_attributes';
	const OPTION_BRANDS = 'premmerce_filter_brands';

	const BRAND_TAXONOMY = 'product_brand';

	/**
	 * @var FileManager
	 */
	private $fileManager;

	/**
	 * @var AdminNotifier
	 */
	private $notifier;

	/**
	 * PluginManager constructor.
	 *
	 * @param string $mainFile
	 */
	public function __construct($mainFile){
		$this->fileManager = new FileManager($mainFile);
		$this->notifier    = new AdminNotifier();

		$this->registerHooks();
	}

	/**
	 * Run plugin part
	 */
	public function run(){
		$valid = count($this->validateRequiredPlugins()) == 0;


		if($valid){
			$subscriber = new FilterSubscriber($this->fileManager);
			$subscriber->subscribe();
		}
		if(is_admin()){
			new Admin($this->fileManager);
		}else{
			$this->registerAssets();
		}
	}

	public function registerHooks(){
		add_action('plugins_loaded', [$this, 'loadTextDomain']);
		add_action('admin_init', [$this, 'checkRequirePlugins']);
	}

	/**
	 * Fired when the plugin is activated
	 */
	public function activate(){

		if(!get_option('premmerce_filter_settings')){
			$defaultOptions = [
				"hide_empty"    => "on",
				"product_cat"   => "on",
				"tag"           => "on",
				"product_brand" => "on",
				"search"        => "on",
				"shop"          => "on",
			];
			add_option('premmerce_filter_settings', $defaultOptions);
		}
	}

	/**
	 * Fired when the plugin is deactivated
	 */
	public function deactivate(){
		$cache = new FilterCache();
		$cache->clear();
		rmdir($cache->getCacheDir());
	}

	/**
	 * Fired during plugin uninstall
	 */
	public static function uninstall(){
		delete_option(self::OPTION_BRANDS);
		delete_option(self::OPTION_ATTRIBUTES);
		delete_option('premmerce_filter_settings');
		delete_option('premmerce_filter_permalink_settings');
	}

	/**
	 * Check required plugins and push notifications
	 */
	public function checkRequirePlugins(){
		$message = __('The %s plugin requires %s plugin to be active!', 'premmerce-filter');

		$plugins = $this->validateRequiredPlugins();

		if(count($plugins)){
			foreach($plugins as $plugin){
				$error = sprintf($message, 'Premmerce WooCommerce Product Filter', $plugin);
				$this->notifier->push($error, AdminNotifier::ERROR, false);
			}
		}

	}

	/**
	 * Validate required plugins
	 *
	 * @return array
	 */
	private function validateRequiredPlugins(){

		$plugins = [];

		if(!function_exists('is_plugin_active')){
			include_once(ABSPATH . 'wp-admin/includes/plugin.php');
		}

		/**
		 * Check if WooCommerce is active
		 **/
		if(!(is_plugin_active('woocommerce/woocommerce.php') || is_plugin_active_for_network('woocommerce/woocommerce.php'))){
			$plugins[] = '<a target="_blank" href="https://wordpress.org/plugins/woocommerce/">WooCommerce</a>';
		}

		return $plugins;
	}

	/**
	 * Load plugin translations
	 */
	public function loadTextDomain(){
		$name = $this->fileManager->getPluginName();
		load_plugin_textdomain('premmerce-filter', false, $name . '/languages/');
	}

	private function registerAssets(){
		add_action("wp_enqueue_scripts", function(){
			wp_enqueue_script('premmerce_filter_script', $this->fileManager->locateAsset('front/js/script.js'), [
				'jquery',
				'jquery-ui-slider',
			], 1.4 . 3, true);
			wp_enqueue_style('premmerce_filter_style', $this->fileManager->locateAsset('front/css/style.css'));
		});
	}
}
