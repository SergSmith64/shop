<?php namespace Premmerce\Filter;

use Premmerce\Filter\Filter\IntersectFilter;
use Premmerce\Filter\Widget\ActiveFilterWidget;
use Premmerce\Filter\Widget\FilterWidget;
use Premmerce\SDK\V1\FileManager\FileManager;

class FilterSubscriber{

	/**
	 * @var FileManager
	 */
	private $fileManager;

	/**
	 * @var array
	 */
	private $settings;

	/**
	 * @var array
	 */
	private $permalinkSettings;

	/**
	 * @var IntersectFilter
	 */
	private $filter;


	public function __construct(FileManager $fileManager){
		$this->fileManager       = $fileManager;
		$this->settings          = get_option('premmerce_filter_settings', []);
		$this->permalinkSettings = get_option('premmerce_filter_permalink_settings', []);
		$this->filter            = new IntersectFilter();
	}

	public function subscribe(){
		add_action('widgets_init', function(){
			register_widget(FilterWidget::class);
			register_widget(ActiveFilterWidget::class);
		});


		add_action('premmerce_product_filter_render', function($data){
			$this->fileManager->includeTemplate('frontend/filter.php', $data);
		});

		add_action('premmerce_product_active_filters_render', function($data){
			$this->fileManager->includeTemplate('frontend/active_filters.php', $data);
		});

		add_action('premmerce_product_filter_widget_form_render', function($data){
			$this->fileManager->includeTemplate('admin/filter-widget.php', $data);
		});

		add_filter('premmerce_product_filter_items', function(){
			return $this->filter->getItems();
		});

		if(!empty($this->settings['show_price_filter'])){
			add_filter('premmerce_product_filter_prices', function(){
				return $this->filter->getPrices();
			});
		}

		add_filter('posts_search', [$this, 'onPostsSearch'], 100, 2);

		add_filter('woocommerce_product_query_tax_query', [$this, 'onWooCommerceTaxQuery']);

		add_filter('premmerce_product_filter_active', [$this, 'onProductFilterActive']);

		add_filter('premmerce_product_filter_hide_empty', function(){
			return isset($this->settings['hide_empty']);
		});

		add_filter('premmerce_product_filter_price_include_fields', function($params){
			return array_filter($params, function($param){
				if(!empty($this->permalinkSettings['permalinks_on'])){

					if(strrpos($param, 'filter_') === 0){
						return false;
					}
					if(strrpos($param, 'query_type_') === 0){
						return false;
					}
				}

				if($param === 'min_price' || $param === 'max_price'){
					return false;
				}

				return true;
			}, ARRAY_FILTER_USE_KEY);
		});
	}


	/**
	 * @param bool $value
	 *
	 * @return bool
	 */
	public function onProductFilterActive($value){
		$settings = $this->settings;

		$category = isset($settings['product_cat']) && is_tax('product_cat');

		$search = isset($settings['search']) && is_search();

		$tag = isset($settings['tag']) && is_product_tag();

		$shop = isset($settings['shop']) && is_shop() && !is_search();

		$brand = isset($settings['product_brand']) && is_tax(FilterPlugin::BRAND_TAXONOMY);

		if($category || $search || $tag || $brand || $shop){
			return true;
		}

		return $value;
	}


	/**
	 * @param string $searchQuery
	 *
	 * @param \WP_Query $wpQuery
	 *
	 * @return string
	 */
	public function onPostsSearch($searchQuery, $wpQuery){

		if($wpQuery->is_search){
			$this->filter->setSearchQuery($searchQuery);
		}

		return $searchQuery;
	}

	/**
	 * Add brand to woocommerce taxonomy query
	 *
	 * @param array $taxQuery
	 *
	 * @return array
	 */
	public function onWooCommerceTaxQuery($taxQuery){
		if(isset($_GET['filter_product_brand']) && $_GET['filter_product_brand']){
			$brand     = sanitize_text_field($_GET['filter_product_brand']);
			$queryType = isset($_GET['query_type_product_brand'])? sanitize_text_field($_GET['query_type_product_brand']) : 'or';

			$brand = [
				"taxonomy"         => FilterPlugin::BRAND_TAXONOMY,
				"field"            => 'slug',
				"terms"            => explode(',', $brand),
				"operator"         => strtolower($queryType) == 'or'? 'in' : 'and',
				"include_children" => false,
			];

			array_unshift($taxQuery, $brand);
		}


		return $taxQuery;
	}

}