<?php namespace Premmerce\Search\Frontend;

use Premmerce\Search\WordpressSDK\FileManager\FileManager;
use WP_Query;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

class RestController{

	/**
	 * @var string
	 */
	private $searchPath;

	/**
	 * @var string
	 */
	private $namespace = 'premmerce-search/v1';

	/**
	 * @var string
	 */
	private $route = '/search';

	/**
	 * @var int
	 */
	private $searchResults = 6;

	/**
	 * @var FileManager
	 */
	private $fileManager;

	public function __construct(FileManager $fileManager){
		$this->fileManager = $fileManager;
		$this->searchPath  = $this->namespace . $this->route;

		add_action('rest_api_init', function(){
			register_rest_route($this->namespace, $this->route, [
				'methods'  => WP_REST_Server::READABLE,
				'callback' => [$this, 'search'],
			]);
		});

		add_action('wp_enqueue_scripts', function() use ($fileManager){

			wp_enqueue_script('premmerce_search', $fileManager->locateAsset('frontend/js/autocomplete.js'), [
				'jquery',
				'jquery-ui-autocomplete',
			]);

			wp_enqueue_style('premmerce_search_css', $fileManager->locateAsset('frontend/css/autocomplete.css'));
			wp_localize_script('premmerce_search', 'premmerceSearch', [
				'url'   => esc_url_raw(rest_url($this->searchPath)),
				'nonce' => wp_create_nonce('wp_rest'),
			]);
		});
	}

	/**
	 * Returns json items by term
	 *
	 * @param WP_REST_Request $request
	 *
	 * @return WP_REST_Response
	 */
	public function search(WP_REST_Request $request){


		$term        = strtolower($request->get_param('term'));
		$suggestions = [];

		$args = [
			'post_type'      => 'product',
			'posts_per_page' => $this->searchResults,
			's'              => $term,
		];

		$loop = new WP_Query($args);

		while($loop->have_posts()){
			$loop->the_post();

			$product = wc_get_product(get_the_ID());

			$suggestion          = [];
			$suggestion['label'] = get_the_title();
			$suggestion['link']  = get_permalink();
			$suggestion['image'] = get_the_post_thumbnail_url();
			$suggestion['price'] = $product->get_price_html();

			$suggestions[] = $suggestion;
		}

		return new WP_REST_Response($suggestions, 200);
	}


}