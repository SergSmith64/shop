<?php namespace Premmerce\Search\Frontend;

use Premmerce\Search\Model\Word;
use Premmerce\Search\WordProcessor;
use WP_Query;
use wpdb;

class SearchHandler{

	/**
	 * @var Word
	 */
	private $word;

	/**
	 * @var WordProcessor
	 */
	private $processor;

	/**
	 * @var wpdb
	 */
	private $wpdb;

	/**
	 * @var array|null
	 */
	private $cachedLikeQueries = null;

	/**
	 * Frontend constructor.
	 *
	 * @param Word $word
	 * @param WordProcessor $processor
	 */
	public function __construct(Word $word, WordProcessor $processor){
		global $wpdb;

		$this->wpdb      = $wpdb;
		$this->word      = $word;
		$this->processor = $processor;

		add_action('posts_search', [$this, 'extendSearch'], 10, 2);
		add_action('posts_fields_request', [$this, 'extendSearchFields'], 10, 2);
		add_action('posts_search_orderby', [$this, 'extendSearchOrder'], 10, 2);
	}

	/**
	 * @param string $fields
	 * @param WP_Query $query
	 *
	 * @return string
	 */
	public function extendSearchFields($fields, WP_Query $query){
		if($query->is_search()){
			$likes = $this->getLikeQueries($query);

			if(count($likes)){
				return $fields . ', (' . implode('+', $likes) . ') as relevance';
			}
		}

		return $fields;
	}

	/**
	 * @param string $orderBy
	 * @param WP_Query $query
	 *
	 * @return string
	 */
	public function extendSearchOrder($orderBy, WP_Query $query){
		if($query->is_search()){
			$likes = $this->getLikeQueries($query);

			if(count($likes)){
				return 'relevance DESC';
			}
		}

		return $orderBy;
	}

	/**
	 * Extends default wordpress search
	 *
	 * @param string $request
	 * @param WP_Query $query
	 *
	 * @return string
	 */
	public function extendSearch($request, WP_Query $query){
		if($query->is_search()){
			$likes = $this->getLikeQueries($query);

			$search = sprintf('AND ((%s) >= 1)', '(' . implode('+', $likes) . ')');

			if(count($likes)){

				//remove woocommerce default search
				remove_filter('posts_where', [WC()->query, 'search_post_excerpt']);

				return $search;
			}
		}

		return $request;
	}

	/**
	 * Create array of like queries for relevance
	 *
	 * @param WP_Query $query
	 *
	 * @return array|null
	 */
	private function getLikeQueries(WP_Query $query){
		if(is_null($this->cachedLikeQueries)){
			$searchWord = mb_strtolower($query->get('s'));

			$searchWords = $this->processor->splitString($searchWord);

			$this->processor->setDictionary($this->word->getWords());

			$matchedWords = $this->processor->matchWords($searchWords);

			//real search string
			$likes[] = '(' . $this->wpdb->prepare("post_title LIKE '%s'", $searchWord . '%') . ') * 2';


			//real search words
			foreach($searchWords as $searchWord){
				$likes[] = '(' . $this->wpdb->prepare("post_title LIKE '%s'", '%' . $searchWord . '%') . ')';
			}


			//found in dictionary
			foreach($matchedWords as $word){
				$likes[] = '(' . $this->wpdb->prepare("post_title LIKE '%s'", '%' . $word . '%') . ')';
			}

			$this->cachedLikeQueries = $likes;
		}

		return $this->cachedLikeQueries;
	}
}
