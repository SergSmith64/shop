<?php namespace Premmerce\Search;

use Premmerce\Search\Admin\Admin;
use Premmerce\Search\Frontend\RestController;
use Premmerce\Search\Frontend\SearchHandler;
use Premmerce\Search\Model\Word;
use Premmerce\Search\WordpressSDK\FileManager\FileManager;
use Premmerce\Search\WordpressSDK\Notifications\AdminNotifier;
use Premmerce\Search\WordpressSDK\Plugin\PluginInterface;

/**
 * Class SearchPlugin
 *
 * @package Premmerce\Search
 */
class SearchPlugin implements PluginInterface{

	const DOMAIN = 'premmerce-search';

	/**
	 * @var FileManager
	 */
	private $fileManager;

	/**
	 * @var Word
	 */
	private $word;

	/**
	 * @var WordProcessor
	 */
	private $wordProcessor;

	/**
	 * @var AdminNotifier
	 */
	private $notifier;


	/**
	 * PluginManager constructor.
	 *
	 * @param string $mainFile
	 */
	public function __construct($mainFile){
		$this->fileManager = new FileManager($mainFile);
		$this->notifier    = new AdminNotifier();

		$this->word          = new Word();
		$this->wordProcessor = new WordProcessor();

		add_action('init', [$this, 'loadTextDomain']);
		add_action('admin_init', [$this, 'checkRequirePlugins']);
	}

	/**
	 * Run plugin part
	 */
	public function run(){
		$valid = count($this->validateRequiredPlugins()) === 0;

		if(is_admin()){
			new Admin($this->fileManager, $this->word, $this->wordProcessor);
		}elseif($valid){
			new SearchHandler($this->word, $this->wordProcessor);
			new RestController($this->fileManager);
		}

	}

	/**
	 * Fired when the plugin is activated
	 */
	public function activate(){
		$this->word->createTable();
	}

	/**
	 * Fired during plugin uninstall
	 */
	public static function uninstall(){
		(new Word())->dropTable();
	}

	/**
	 * Check required plugins and push notifications
	 */
	public function checkRequirePlugins(){
		$message = __('The %s plugin requires %s plugin to be active!', 'premmerce-search');

		$plugins = $this->validateRequiredPlugins();

		if(count($plugins)){
			foreach($plugins as $plugin){
				$error = sprintf($message, 'Premmerce Search', $plugin);
				$this->notifier->push($error, AdminNotifier::ERROR, false);
			}
		}

	}

	/**
	 * Validate required plugins
	 *
	 * @return array
	 */
	private function validateRequiredPlugins(){

		$plugins = [];

		if(!function_exists('is_plugin_active')){
			include_once(ABSPATH . 'wp-admin/includes/plugin.php');
		}

		/**
		 * Check if WooCommerce is active
		 **/
		if(!(is_plugin_active('woocommerce/woocommerce.php') || is_plugin_active_for_network('woocommerce/woocommerce.php'))){
			$plugins[] = '<a target="_blank" href="https://wordpress.org/plugins/woocommerce/">WooCommerce</a>';
		}

		return $plugins;
	}

	/**
	 * Load plugin translations
	 */
	public function loadTextDomain(){
		$name = $this->fileManager->getPluginName();
		load_plugin_textdomain(self::DOMAIN, false, $name . '/languages/');
	}

	/**
	 * Fired when the plugin is deactivated
	 */
	public function deactivate(){
	}
}
