<?php use Premmerce\Search\SearchPlugin; ?>
<p><?php _e("We recommend that you update the indexes after the products have been changed", SearchPlugin::DOMAIN) ?></p>
<form method="post">
    <button value="1" name="<?php echo SearchPlugin::DOMAIN ?>-update-indexes"
            type="submit"><?php _e('Update indexes', SearchPlugin::DOMAIN) ?></button>
</form>
