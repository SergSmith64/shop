<?php
if(function_exists('premmerce_ps_fs')){
	premmerce_ps_fs()->_contact_page_render();
}
