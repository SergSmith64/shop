jQuery(function ($) {
    var search = $('[id^="woocommerce-product-search-field-"]');

    search.each(function () {
        var search = $(this);

        search.autocomplete({
            source: function (name, response) {
                $.get(premmerceSearch.url, name, function (data) {
                    response(data);
                }, 'json');
            },
            delay: 500,
            minLength: 3
        });

        search.autocomplete('instance')._renderItem = function (ul, item) {

            var content = $('<a>', {href: item.link, class: 'search-item__link'});

            if (item.image) {
                var image = $('<img>', {
                    class: 'search-item__thumbnail',
                    src: item.image,
                });
                content.append(image);
            }

            var label = $('<span>', {class: 'search-item__label'});

            label.append(item.label + item.price);

            content.append(label);

            var li = $('<li>', {'class': 'search-item'}).css('width', search.css('width')).appendTo(ul);

            li.append(content);

            return li;


        };
    });


});
