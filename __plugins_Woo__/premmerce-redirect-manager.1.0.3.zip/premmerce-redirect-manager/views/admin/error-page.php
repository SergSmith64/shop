<?php
if(!defined('ABSPATH')){
	exit;
}
?>
<div class="notice notice-error is-dismissible">
    <p>
        <?= $errorMessage; ?>
    </p>
</div>