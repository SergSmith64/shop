=== Premmerce Redirect Manager ===

Contributors: premmerce
Tags: wordpress redirect manager, 301 redirects manager, woocommerce redirect manager
Requires at least: 4.8
Tested up to: 5.0
Stable tag: 1.0.3
Requires PHP: 5.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The Premmerce Redirect Manager enables you to create 301 and 302 redirects and to set up the automatic redirects for the deleted products in the WooCommerce store.

== Description ==

The Premmerce Redirect Manager enables you to create 301 and 302 redirects and to set up the automatic redirects for the deleted products in the WooCommerce store.
This is the main Premmerce plugin for the redirect management and it focuses on the  improvement of  your store’s SEO, usability and navigation.
At the moment we are working on the tools needed for migration from other platforms to WooCommerce and the Redirect Manager would ensure the seamless flow of this process. We make sure your store doesn’t lose its position in the search engine.
Full documentation is available here: [Premmerce Redirect Manager](https://premmerce.com/woocommerce-redirect-manager/)

= Major features in "Premmerce Redirect Manager" =

* adding 301 redirects
* adding 302 redirects
* setting up automatic redirects for products
* a convenient interface for  adding and editing redirects

= Demo =

You can create your personal demo store and test  this plugin together with [Premmerce Premium](https://premmerce.com/features/) and all other Premmerce plugins and themes  developed by our team here:  [Premmerce WooCommerce Demo](https://premmerce.com/premmerce-woocommerce-demo/).


= Compatibility with other Plugins =

* WooCommerce
* WooCommerce Multilingual
* WPML

== Screenshots ==

1. Displaying the redirects list
2. Displaying the settings page


== Frequently Asked Questions ==

= Documentation =
Full documentation is available here: [Premmerce Redirect Manager](https://premmerce.com/woocommerce-redirect-manager/)

= Installation Instructions =
Go to Plugins -> Add New section from your admin account and search for Premmerce Redirect Manager.

You can also install this plugin manually:
* Download the plugin’s ZIP archive and unzip it.
* Copy the unzipped premmerce-woocommerce-product-filter folder to the /wp-content/plugins/ directory.
* Activate the plugin through the ‘Plugins’ menu in WordPress

== Changelog ==

= 1.0 =

Release Date: Jan 11, 2018

= 1.0.1 =

Release Date: Jan 24, 2018

* Fixed redirect from url with trailing slash
* Fixed ulr which does not begin with slash

= 1.0.2 =

Release Date: Feb 02, 2018

* Updated translations

= 1.0.3 =

Release Date: Aug 21, 2018

* Fixed translations
* Fixed security issues
* Updated freemius SDk
* Updated premmerce SDk
