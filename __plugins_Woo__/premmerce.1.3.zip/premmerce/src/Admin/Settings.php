<?php namespace Premmerce\Premmerce\Admin;


use Premmerce\Premmerce\Behat\Transliterator\Transliterator;

class Settings{


	const OPTIONS_KEY = 'premmerce_additional_settings';
	private $options;

	public function addActions(){
		add_action('admin_init', [$this, 'initSettings']);

		add_filter('rocket_common_cache_logged_users', function($default){
			if($this->getOption('rocket_common_cache_logged_users') === 'on'){
				return true;
			}

			return $default;
		});
		add_filter('sanitize_title', function($title){
			if($this->getOption('transliterate_slugs') === 'on'){
				return Transliterator::utf8ToAscii($title);
			}

			return $title;
		}, 9);
	}


	public function initSettings(){

		register_setting('premmerce_settings', self::OPTIONS_KEY);

		add_settings_section(
			'cache',
			__('Cache', 'premmerce'),
			'',
			'premmerce'
		);
		add_settings_section(
			'slugs',
			__('Slugs', 'premmerce'),
			'',
			'premmerce'
		);


		add_settings_field(
			__('Use the same cache for all logged in users', 'premmerce'),
			'',
			[$this, 'checkboxCallback'],
			'premmerce',
			'cache',
			[
				'label'     => __('Use the same cache for all logged in users', 'premmerce'),
				'label_for' => 'rocket_common_cache_logged_users',
			]
		);


		add_settings_field(
			'transliterate_slugs',
			'',
			[$this, 'checkboxCallback'],
			'premmerce',
			'slugs',
			[
				'label'     => __('Enable slugs transliteration', 'premmerce'),
				'label_for' => 'transliterate_slugs',
			]
		);

	}


	public function checkBoxCallback($args){
		$checkbox = '<label ><input type="checkbox" name="premmerce_additional_settings[%s]" %s >%s</label>';
		$checked  = $this->getOption($args['label_for']);
		printf($checkbox, esc_attr($args['label_for']), checked('on', $checked, false), $args['label']);
	}

	private function getOption($key, $default = null){
		if(is_null($this->options)){
			$this->options = get_option(self::OPTIONS_KEY);
		}

		return isset($this->options[ $key ])? $this->options[ $key ] : $default;
	}
}