<?php

/**
 * Premmerce WooCommerce Product Comparison plugin
 *
 *
 * @link              http://premmerce.com
 * @since             1.0.0
 * @package           Premmerce\ProductComparison
 *
 * @wordpress-plugin
 * Plugin Name:       Premmerce Product Comparison
 * Plugin URI:        http://premmerce.com
 * Description:       Premmerce WooCommerce Product Comparison
 * Version:           1.0
 * Author:            Premmerce
 * Author URI:        http://premmerce.com
 * License:           GPL-2.0+
 */