<?php
    use Premmerce\ProductComparison\ProductComparisonPlugin;
?>

<div class="product_comparison_wrap">
    <?php if (premmerce_comparison()->checkInComparison($productId)): ?>
        <a class="button alt" href="<?php echo get_permalink(get_post(get_option(ProductComparisonPlugin::OPTION_PAGE))); ?>">
            <?php _e('Compare',ProductComparisonPlugin::DOMAIN); ?>
        </a>
    <?php else: ?>
        <form method="post" action="<?php echo $url; ?>">
            <input type="hidden" name="comparison_product_id" value="<?php echo $productId; ?>">

            <input type="submit"
                   name="submit"
                   id="submit"
                   class="button alt"
                   value="<?php _e('Add to Comparison', ProductComparisonPlugin::DOMAIN) ?>"
            />

            <?php wp_nonce_field('wp_rest'); ?>
        </form>
    <?php endif; ?>
</div>
