<?php use Premmerce\ProductComparison\ProductComparisonPlugin; ?>

<?php if (!count($data)): ?>
    <p>
        <?php _e('There are no products to compare',ProductComparisonPlugin::DOMAIN); ?>
    </p>
<?php else: ?>

    <?php foreach ($data as $category): ?>

        <div>
            <h4>
                <a href="<?= $category['url']; ?>">
                    <?= $category['name']; ?>
                </a>
            </h4>

            <?php foreach ($category['products'] as $product): ?>
                <div style="display: inline-block">

                    <?php
                    if ($product->get_type() == 'variation') {
                        $imgId = $product->get_parent_data()['image_id'];
                    } else {
                        $imgId = $product->get_image_id();
                    }
                    ?>

                    <a href="<?php echo get_permalink($product->get_id()); ?>">
                        <img height="100" width="100" src="<?php echo wp_get_attachment_url( $imgId ) ?>">
                    </a>

                    <div>
                        <a href="<?php echo get_permalink($product->get_id()); ?>"><?php echo $product->get_name() ?></a>
                    </div>

                    <div>
                        <a href="<?php echo wp_nonce_url($urlDelete . $product->get_id(),'wp_rest'); ?>">
                            X
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>

        </div>

    <?php endforeach; ?>

<?php endif; ?>
