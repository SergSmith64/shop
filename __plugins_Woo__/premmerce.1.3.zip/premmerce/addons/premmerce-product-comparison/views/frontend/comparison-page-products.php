<?php

if (!count($data)) {
    return;
}

?>

<div>
    <table>
        <thead>
            <td></td>
            <?php foreach ($data['products'] as $product): ?>
                <td>
                    <div style="display: inline-block">
                        <?php
                        if ($product->get_type() == 'variation') {
                            $imgId = $product->get_parent_data()['image_id'];
                        } else {
                            $imgId = $product->get_image_id();
                        }
                        ?>

                        <a href="<?php echo get_permalink($product->get_ID()); ?>">
                            <img height="100" width="100" src="<?php echo wp_get_attachment_url($imgId) ?>">
                        </a>

                        <div>
                            <a href="<?php echo get_permalink($product->get_ID()); ?>"><?php echo $product->get_name() ?></a>
                        </div>

                        <div>
                            <a href="<?php echo wp_nonce_url($urlDelete . $product->get_id(),'wp_rest') . '&products=' . implode(',',array_keys($data['products'])); ?>">
                                X
                            </a>
                        </div>
                    </div>
                </td>
            <?php endforeach; ?>
        </thead>
        <tbody>
            <?php foreach ($data['attributes'] as $attr): ?>
                <tr>
                    <td><?= $attr['title']; ?></td>

                    <?php foreach ($attr['values'] as $value): ?>
                        <td><?= $value ? $value : '-'; ?></td>
                    <?php endforeach; ?>

                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
