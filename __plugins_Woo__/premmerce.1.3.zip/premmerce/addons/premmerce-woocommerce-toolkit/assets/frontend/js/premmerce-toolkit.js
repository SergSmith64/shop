(function ($) {
    'use strict';
})(jQuery);