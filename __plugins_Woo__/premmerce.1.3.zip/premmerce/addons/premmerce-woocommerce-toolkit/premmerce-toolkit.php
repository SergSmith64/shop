<?php

/**
 * Premmerce WooCommerce Toolkit
 *
 * @package           Premmerce\Toolkit
 *
 * @wordpress-plugin
 * Plugin Name:       Premmerce WooCommerce Toolkit
 * Plugin URI:        https://premmerce.com/woocommerce-toolkit-catalog-mode-product-video/
 * Description:       Plugin add different upgrades
 * Version:           1.1.5
 * Author:            premmerce
 * Author URI:        https://premmerce.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       premmerce-toolkit
 * Domain Path:       /languages
 *
 */