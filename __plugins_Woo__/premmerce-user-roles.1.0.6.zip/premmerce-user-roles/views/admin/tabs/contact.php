<?php
if ( ! defined('WPINC')) {
    die;
}

if (function_exists('premmerce_re_fs')) {
    premmerce_re_fs()->_contact_page_render();
}
