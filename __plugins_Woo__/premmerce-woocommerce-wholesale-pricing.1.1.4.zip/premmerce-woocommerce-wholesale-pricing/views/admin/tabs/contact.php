<?php
if ( ! defined('WPINC')) {
    die;
}

if (function_exists('premmerce_ppt_fs')) {
    premmerce_ppt_fs()->_contact_page_render();
}
