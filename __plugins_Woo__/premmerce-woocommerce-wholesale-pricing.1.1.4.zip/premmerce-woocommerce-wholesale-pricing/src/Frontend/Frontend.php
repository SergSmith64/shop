<?php namespace Premmerce\PriceTypes\Frontend;

use Premmerce\PriceTypes\Models\AdminModel;
use WC_Product;

/**
 * Class Frontend
 *
 * @package Premmerce\PriceTypes\Frontend
 */
class Frontend
{
    /**
     * @var AdminModel
     */
    private $model;

    /**
     * Frontend constructor.
     *
     * @param AdminModel $model
     */
    public function __construct(AdminModel $model)
    {
        $this->model = $model;

        // set prices for products
        add_filter('woocommerce_product_get_price', array($this,'getProductPrice'), 101, 2);
        add_filter('woocommerce_product_get_sale_price', array($this,'getProductPrice'), 101, 2);
        add_filter('woocommerce_product_get_regular_price', array($this,'getProductPrice'), 101, 2);

        // set prices for variation
        add_filter('woocommerce_product_variation_get_price', array($this,'getProductPrice'), 101, 2);
        add_filter('woocommerce_product_variation_get_sale_price', array($this,'getProductPrice'), 101, 2);
        add_filter('woocommerce_product_variation_get_regular_price', array($this,'getProductPrice'), 101, 2);

        // set variate range html
        add_filter('woocommerce_variation_prices_price', array($this,'getProductPrice'), 101, 2);
        add_filter('woocommerce_variation_prices_sale_price', array($this,'getProductPrice'), 101, 2);
        add_filter('woocommerce_variation_prices_regular_price', array($this,'getProductPrice'), 101, 2);
    }

    /**
     * Replace product price
     *
     * @param string $price
     * @param WC_Product $product
     *
     * @return int
     */
    public function getProductPrice($price, $product)
    {
        if (apply_filters('premmerce_wholesale_only_for_registered', is_user_logged_in())) {
            $user = wp_get_current_user();

            $priceTypeIds = $this->model->getPriceTypeByUserRoles($user->roles);

            if ($priceTypeIds) {
                $newPrices = array();

                foreach ($priceTypeIds as $priceType) {
                    $value = get_post_meta($product->get_ID(), '_price_types_' . $priceType, true);

                    if ($value) {
                        $newPrices[] = $value;
                    }
                }

                if ($newPrices) {
                    $price = apply_filters('premmerce_wholesale_pricing_get_price', min($newPrices), $product);
                    $price = wc_format_decimal($price);
                }
            }
        }

        return $price;
    }
}
