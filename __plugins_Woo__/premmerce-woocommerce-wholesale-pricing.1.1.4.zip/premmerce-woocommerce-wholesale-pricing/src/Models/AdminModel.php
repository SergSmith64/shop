<?php namespace Premmerce\PriceTypes\Models;

/**
 * Class AdminModel
 * @package Premmerce\PriceTypes\Models
 */
class AdminModel
{
    /**
     * Db table name without prefix
     */
    const TBL_NAME_PRICE_TYPES = 'premmerce_price_types';

    /**
     * Db table name without prefix
     */
    const TBL_NAME_PRICE_TYPES_ROLES = 'premmerce_price_types_roles';

    /**
     * Prefix for DB table
     *
     * @var string
     */
    private $prefix = '';

    /**
     * Charset for DB table
     *
     * @var string
     */
    private $charset = '';

    /**
     * Collate for DB table
     *
     * @var string
     */
    private $collate = '';

    /**
     * AdminModel constructor.
     *
     */
    public function __construct()
    {
        global $wpdb;

        $this->prefix  = $wpdb->prefix;
        $this->charset = $wpdb->charset;
        $this->collate = $wpdb->collate;
    }

    /**
     * Create plugin tables
     */
    public function createTables()
    {
        $sql = vsprintf(
            'CREATE TABLE IF NOT EXISTS %s (
              `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
              `name` varchar(255) NOT NULL DEFAULT "",
              PRIMARY KEY  (`ID`)
            ) ENGINE=InnoDB DEFAULT CHARACTER SET %s COLLATE %s;',
            array(
                $this->prefix . self::TBL_NAME_PRICE_TYPES,
                $this->charset,
                $this->collate
            )
        );

        $this->runQuery($sql);

        $sql = vsprintf(
            'CREATE TABLE IF NOT EXISTS %s (
                `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                `price_type_id` bigint(20) unsigned DEFAULT NULL,
                `role` varchar(255) NOT NULL DEFAULT "",
                PRIMARY KEY  (`ID`)
            ) ENGINE=InnoDB DEFAULT CHARACTER SET %s COLLATE %s;',
            array(
                $this->prefix . self::TBL_NAME_PRICE_TYPES_ROLES,
                $this->charset,
                $this->collate
            )
        );

        $this->runQuery($sql);
    }

    /**
     * Delete plugin tables.
     */
    public function deleteTables()
    {
        $sql = 'DROP TABLE IF EXISTS ' . $this->prefix . self::TBL_NAME_PRICE_TYPES;
        $this->runQuery($sql);

        $sql = 'DROP TABLE IF EXISTS ' . $this->prefix . self::TBL_NAME_PRICE_TYPES_ROLES;
        $this->runQuery($sql);
    }

    /**
     * Create new price type
     *
     * @param array $priceTypes
     *
     * @return int
     */
    public function addPriceTypes($priceTypes)
    {
        $sql = vsprintf(
            'INSERT INTO `%s` (`name`) VALUES (\'%s\');',
            array(
                $this->getTblNamePriceTypes(),
                $priceTypes['name'],
            )
        );

        if ($this->runQuery($sql)) {
            $lastId = $this->getInsertId();

            if ($this->addPriceTypesRoles($lastId, $priceTypes['roles'])) {
                return $lastId;
            }
        }
    }

    /**
     * Create new price types roles
     *
     * @param int $priceTypeId
     * @param array $roles
     *
     * @return bool
     */
    private function addPriceTypesRoles($priceTypeId, $roles)
    {
        $values = array();
        foreach ($roles as $role) {
            $values[] = vsprintf('(%u, \'%s\')', array(
                $priceTypeId,
                $role,
            ));
        }

        $sql = vsprintf(
            'INSERT INTO `%s` (`price_type_id`,`role`) VALUES %s;',
            array(
                $this->getTblNamePriceTypesRoles(),
                implode(', ', $values),
            )
        );

        return $this->runQuery($sql);
    }

    /**
     * Edit price type
     *
     * @param array $priceTypes
     *
     * @return bool
     */
    public function editPriceTypes($priceTypes)
    {
        $sql = vsprintf(
            'UPDATE `%s` SET `name` = \'%s\' WHERE `ID` = %s;',
            array(
                $this->getTblNamePriceTypes(),
                $priceTypes['name'],
                $priceTypes['ID'],
            )
        );

        if ($this->runQuery($sql)) {
            return $this->editPriceTypesRoles($priceTypes);
        }
    }

    /**
     * Edit price types roles
     *
     * @param $priceTypes
     *
     * @return false|int
     */
    private function editPriceTypesRoles($priceTypes)
    {
        if ($this->deletePriceTypesRoles(array($priceTypes['ID']))) {
            return $this->addPriceTypesRoles($priceTypes['ID'], $priceTypes['roles']);
        }
    }

    /**
     * Delete price types by ids list
     *
     * @param array $ids
     *
     * @return bool
     */
    public function deletePriceTypes($ids = array())
    {
        $sql = vsprintf(
            'DELETE FROM `%s` WHERE `id` IN (%s);',
            array(
                $this->getTblNamePriceTypes(),
                implode(', ', $ids)
            )
        );

        if ($this->runQuery($sql)) {
            $this->deletePriceTypesRoles($ids);
            $this->deletePriceTypesPrices($ids);

            return true;
        }
    }

    /**
     * Delete price types roles by ids list
     *
     * @param array $priceTypeIds
     *
     * @return bool
     */
    private function deletePriceTypesRoles($priceTypeIds = array())
    {
        $sql = vsprintf(
            'DELETE FROM `%s` WHERE `price_type_id` IN (%s);',
            array(
                $this->getTblNamePriceTypesRoles(),
                implode(', ', $priceTypeIds)
            )
        );

        return $this->runQuery($sql);
    }

    /**
     * Delete price types prices by ids list
     *
     * @param array $priceTypeIds
     *
     * @return bool
     */
    private function deletePriceTypesPrices($priceTypeIds = array())
    {
        $values = array();
        foreach ($priceTypeIds as $id) {
            $values[] = '\'_price_types_' . $id . '\'';
        }

        $sql = vsprintf(
            'DELETE FROM `wp_postmeta` WHERE `meta_key` IN (%s);',
            array(
                implode(', ', $values)
            )
        );

        return $this->runQuery($sql);
    }

    /**
     * Get table name with DB prefix
     *
     * @return string
     */
    private function getTblNamePriceTypes()
    {
        return $this->prefix . self::TBL_NAME_PRICE_TYPES;
    }

    /**
     * Get table name with DB prefix
     *
     * @return string
     */
    private function getTblNamePriceTypesRoles()
    {
        return $this->prefix . self::TBL_NAME_PRICE_TYPES_ROLES;
    }

    /**
     * Get id of last inserted row
     *
     * @return int
     */
    private function getInsertId()
    {
        global $wpdb;

        return $wpdb->insert_id;
    }

    /**
     * Get data from tables
     *
     * @param string $sql
     *
     * @return array
     */
    private function getResults($sql)
    {
        global $wpdb;


        $key = md5($sql);

        $result = wp_cache_get($key);

        if (false !== $result) {
            return $result;
        }

        $results = $wpdb->get_results($sql, ARRAY_A);

        wp_cache_set($key, $results);

        return $results;
    }

    /**
     * Get price type
     *
     * @param string $id
     *
     * @return array
     */
    public function getPriceType($id)
    {
        $data = array();

        $sql = vsprintf(
            'SELECT `t1`.`ID` AS "ID", `t2`.`ID` AS "roleID", `t1`.`name`, `t2`.`role` 
            FROM `%s` AS t1 
            LEFT JOIN `%s` AS t2 ON t2.price_type_id = t1.id
            WHERE `t1`.`ID` = %s;',
            array(
                $this->getTblNamePriceTypes(),
                $this->getTblNamePriceTypesRoles(),
                $id
            )
        );

        $priceTypes = $this->getResults($sql);

        if ($priceTypes) {
            foreach ($priceTypes as $key => $priceType) {
                $data['ID']                          = $priceType['ID'];
                $data['name']                        = $priceType['name'];
                $data['roles'][$priceType['roleID']] = $priceType['role'];
            }
        }

        return $data;
    }

    /**
     * Get data from db table price_types
     *
     * @return array
     */
    public function getPriceTypes()
    {
        $data = array();

        $sql = vsprintf(
            'SELECT `t1`.`ID` AS "ID", `t2`.`ID` AS "roleID", `t1`.`name`, `t2`.`role` 
            FROM `%s` AS t1 
            LEFT JOIN `%s` AS t2 ON t2.price_type_id = t1.id;',
            array(
                $this->getTblNamePriceTypes(),
                $this->getTblNamePriceTypesRoles(),
            )
        );

        $priceTypes = $this->getResults($sql);

        if ($priceTypes) {
            foreach ($priceTypes as $key => $priceType) {
                $data[$priceType['ID']]['ID']                          = $priceType['ID'];
                $data[$priceType['ID']]['name']                        = $priceType['name'];
                $data[$priceType['ID']]['roles'][$priceType['roleID']] = $priceType['role'];
            }
        }

        return $data;
    }

    /**
     * Get data from db table price_types_roels
     *
     * @param int $priceTypeId
     *
     * @return array
     */
    public function getPriceTypesRoles($priceTypeId = 0)
    {
        $data = array();

        $where = '';
        if ($priceTypeId) {
            $where = vsprintf(
                'WHERE `price_type_id` <> %s',
                array(
                    $priceTypeId,
                )
            );
        }

        $sql = vsprintf(
            'SELECT * FROM `%s` %s;',
            array(
                $this->getTblNamePriceTypesRoles(),
                $where
            )
        );

        $roles = $this->getResults($sql);

        if ($roles) {
            foreach ($roles as $role) {
                $data[] = $role['role'];
            }
        }

        return $data;
    }

    /**
     * Get data from db table price_types_prices
     *
     * @param int $productId
     * @param int $variationId
     *
     * @return array
     */
    public function getPriceTypesPrices($productId, $variationId = 0)
    {
        $data = array();

        $sql = vsprintf(
            'SELECT * FROM `%s` WHERE `product_id` = %s AND `variant_id` = %s;',
            array(
                $this->getTblNamePriceTypesPrices(),
                $productId,
                $variationId
            )
        );

        $prices = $this->getResults($sql);

        if ($prices) {
            foreach ($prices as $price) {
                $data[$price['price_type_id']] = $price;
            }
        }

        return $data;
    }

    /**
     * Get list of price types ids by user roles
     *
     * @param array $roles
     *
     * @return array
     */
    public function getPriceTypeByUserRoles($roles)
    {
        $roles = apply_filters('premmerce_wholesale_get_price_type_by_user_roles', $roles);
        $roles = array_map(function ($item) {
            return '\'' . $item . '\'';
        }, $roles);

        $sql = vsprintf(
            'SELECT `price_type_id` FROM `%s` WHERE `role` IN (%s);',
            array(
                $this->getTblNamePriceTypesRoles(),
                implode(', ', $roles),
            )
        );

        $data = $this->getResults($sql);

        if ($data) {
            return array_column($data, 'price_type_id');
        }
    }

    /**
     * Execute query
     *
     * @param string $sql
     *
     * @return bool
     */
    private function runQuery($sql)
    {
        global $wpdb;

        if ($wpdb->query($sql) !== false) {
            return true;
        }
    }

    /**
     * Check price type id is it exist
     *
     * @param int $id
     *
     * @return bool
     */
    public function validatePriceTypeId($id)
    {
        $sql = vsprintf(
            'SELECT * FROM `%s` WHERE `id` = %s',
            array(
                $this->getTblNamePriceTypes(),
                $id
            )
        );

        return $this->getResults($sql) ? true : false;
    }
}
