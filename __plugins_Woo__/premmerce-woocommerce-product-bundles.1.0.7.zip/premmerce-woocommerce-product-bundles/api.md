### Shortcode

1. Shortcode render bundle by id
    
        [premmerce_get_bundle_by_id id=3]

1. Shortcode render bundles by main product id 

        [premmerce_get_bundles_by_main_product_id id=393]
