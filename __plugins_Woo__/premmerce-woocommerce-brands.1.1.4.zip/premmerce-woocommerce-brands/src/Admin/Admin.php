<?php namespace Premmerce\Brands\Admin;

use Premmerce\Brands\WordpressSDK\FileManager\FileManager;

/**
 * Class Admin
 * @package Premmerce\Brands\Admin
 */
class Admin{

	/**
	 * @var FileManager
	 */
	private $fileManager;

	/**
	 * Admin constructor.
	 *
	 * @param FileManager $fileManager
	 */
	public function __construct(FileManager $fileManager){
		$this->registerHooks();

		$this->fileManager = $fileManager;
	}

	/**
	 * Register backend hooks
	 */
	private function registerHooks(){
		add_action('product_brand_add_form_fields', [$this, 'addBrandsFields']);
		add_action('product_brand_edit_form_fields', [$this, 'editBrandsFields'], 10);
		add_action('created_term', [$this, 'saveBrandsFields'], 10, 3);
		add_action('edit_term', [$this, 'saveBrandsFields'], 10, 3);
		add_filter('manage_edit-product_brand_columns', [$this, 'productBrandColumns']);
		add_filter('manage_product_brand_custom_column', [$this, 'productCatColumn'], 10, 3);
		add_action('quick_edit_custom_box', [$this, 'quickEdit'], 10, 2);
		add_action('manage_product_posts_custom_column', [$this, 'renderProductColumns']);
		add_action('woocommerce_product_bulk_and_quick_edit', [$this, 'saveEditPost']);
	}

	/**
	 * Include add_brands_fields template
	 */
	public function addBrandsFields(){
		wp_enqueue_media();
		wp_enqueue_style('premmerce-brands', $this->fileManager->locateAsset('admin/css/premmerce-brands.css'));
		wp_enqueue_script('premmerce-brands', $this->fileManager->locateAsset('admin/js/premmerce-brands.js'));

		$this->fileManager->includeTemplate('admin/create-brands-fields.php');
	}

	/**
	 * Include edit_brands_fields template
	 *
	 * @param \WP_Term $term
	 */
	public function editBrandsFields(\WP_Term $term){
		wp_enqueue_media();
		wp_enqueue_style('premmerce-brands', $this->fileManager->locateAsset('admin/css/premmerce-brands.css'));
		wp_enqueue_script('premmerce-brands', $this->fileManager->locateAsset('admin/js/premmerce-brands.js'));

		$thumbnailId = absint(get_term_meta($term->term_id, 'thumbnail_id', true));

		if($thumbnailId){
			$image = wp_get_attachment_thumb_url($thumbnailId);
		}else{
			$image = wc_placeholder_img_src();
		}

		$this->fileManager->includeTemplate('admin/edit-brands-fields.php', [
			'thumbnailId' => $thumbnailId,
			'image'       => $image,
		]);
	}

	/**
	 * Update custom brands fields
	 *
	 * @param int $termId
	 * @param string $ttId
	 * @param string $taxonomy
	 */
	public function saveBrandsFields($termId, $ttId = '', $taxonomy = ''){
		if(isset($_POST['brands_thumbnail_id']) && 'product_brand' === $taxonomy){
			update_term_meta($termId, 'thumbnail_id', absint($_POST['brands_thumbnail_id']));
		}
	}

	/**
	 * Ad image column to brands page
	 *
	 * @param array $columns
	 *
	 * @return array
	 */
	public function productBrandColumns($columns){
		$newColumns = [];

		if(isset($columns['cb'])){
			$newColumns['cb'] = $columns['cb'];
			unset($columns['cb']);
		}

		$newColumns['thumb'] = __('Image', 'premmerce-brands');

		return array_merge($newColumns, $columns);
	}

	/**
	 * Display brand image
	 *
	 * @param array $columns
	 * @param string $column
	 * @param int $id
	 *
	 * @return string
	 */
	public function productCatColumn($columns, $column, $id){
		if($column == 'thumb'){
			$thumbnailId = get_term_meta($id, 'thumbnail_id', true);

			if($thumbnailId){
				$image = wp_get_attachment_thumb_url($thumbnailId);
			}else{
				$image = wc_placeholder_img_src();
			}

			$columns .= '<img src="' . esc_url($image) . '" alt="' . esc_attr__('Image', 'premmerce-brands') . '" class="wp-post-image" height="48" width="48" />';
		}

		return $columns;
	}

	/**
	 * Add brands radio to quick edit
	 *
	 * @param string $columnName
	 * @param string $postType
	 */
	public function quickEdit($columnName, $postType){
		if($postType == 'product' && $columnName == 'product_cat'){
			$brands = get_terms('product_brand', [
				'orderby'    => 'name',
				'order'      => 'ASC',
				'hide_empty' => false,
			]);

			$this->fileManager->includeTemplate('admin/brands-quick-edit.php', [
				'brands' => $brands,
			]);
		}
	}

	/**
	 * View hidden input for js (because no flexible WP)
	 *
	 * @param string $column
	 */
	public function renderProductColumns($column){
		wp_enqueue_script('premmerce-brands', $this->fileManager->locateAsset('admin/js/premmerce-brands.js'));

		if($column == 'name'){
			global $post;

			$brands = get_the_terms($post->ID, 'product_brand');

			if(isset($brands[0])){
				echo '<input type="hidden" data-input="product_brand" value="' . $brands[0]->slug . '">';
			}
		}
	}

	/**
	 * Save brand from quick edit form
	 *
	 * @param int $postId
	 */
	public function saveEditPost($postId){
		if(isset($_POST['product_brand'])){
			wp_set_post_terms($postId, $_POST['product_brand'], 'product_brand');
		}else{
			wp_set_post_terms($postId, '', 'product_brand');
		}
	}
}
