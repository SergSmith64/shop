<?php
if(function_exists('premmerce_wpm_fs')){
	premmerce_wpm_fs()->_contact_page_render();
}
