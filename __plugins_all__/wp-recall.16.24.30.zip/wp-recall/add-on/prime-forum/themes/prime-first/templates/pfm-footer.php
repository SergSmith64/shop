<div class="prime-forum-footer">

	<?php do_action( 'pfm_footer' ); ?>

</div>

